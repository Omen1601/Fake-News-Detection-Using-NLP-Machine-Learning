# app.py

from flask import Flask, render_template, request, jsonify
import joblib

app = Flask(__name__)

# Load the pre-trained model and vectorizer
model = joblib.load('pa_classifier_model.pkl')
vectorizer = joblib.load('tfidf_vectorizer.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        text = request.form['text']

        # Vectorize the input text
        text_vectorized = vectorizer.transform([text])

        # Make predictions
        prediction = model.predict(text_vectorized)[0]

        # Return the result
        result = {'prediction': 'Fake' if prediction == 1 else 'Real'}
        return render_template('index.html', prediction=result['prediction'], text=text)

    except Exception as e:
        return render_template('index.html', error=str(e))

if __name__ == '__main__':
    app.run(port=5000, debug=True)

