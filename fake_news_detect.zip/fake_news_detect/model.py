# model.py

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.pipeline import Pipeline
import joblib

df = pd.read_csv('news.csv')
# Columns: 'Unnamed: 0', 'title', 'text', 'label'

# Drop unnecessary columns
df = df.drop(columns=['Unnamed: 0'])

# Split the data into training and testing sets
train_data, test_data, train_labels, test_labels = train_test_split(df['text'], df['label'], test_size=0.2, random_state=42)

# Create a pipeline with TF-IDF vectorizer and PassiveAggressiveClassifier
model = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english')),
    ('clf', PassiveAggressiveClassifier(max_iter=50, random_state=42))
])

# Train the model
model.fit(train_data, train_labels)

# Save the model and vectorizer
joblib.dump(model, 'pa_classifier_model.pkl')
joblib.dump(model.named_steps['tfidf'], 'tfidf_vectorizer.pkl')
